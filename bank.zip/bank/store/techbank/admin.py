from django.contrib import admin

# Register your models here.
# views.py or admin.py

